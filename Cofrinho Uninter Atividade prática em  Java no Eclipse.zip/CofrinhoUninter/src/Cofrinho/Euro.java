package Cofrinho;

public class Euro extends Moeda {
    private static final double TAXA_EURO = 5.60;

    public Euro(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Moeda: Euro - Valor: €" + valor);
    }

    @Override
    public double converter() {
        return this.valor * TAXA_EURO;
    }
}