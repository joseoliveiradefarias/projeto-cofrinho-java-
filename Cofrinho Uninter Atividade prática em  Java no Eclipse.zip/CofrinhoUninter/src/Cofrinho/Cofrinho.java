package Cofrinho; // Certifique-se de que o nome do pacote está correto!

import java.util.ArrayList;
import java.util.List;
//A classe Cofrinho gerencia a coleção de moedas, permitindo adicionar, remover, listar e calcular o total.
public class Cofrinho {
	 // 'listaMoedas' é a coleção que armazena os objetos do tipo Moeda.
    private List<Moeda> listaMoedas;

    public Cofrinho() {
        this.listaMoedas = new ArrayList<>();
    }

    public void adicionar(Moeda moeda) {
        this.listaMoedas.add(moeda);
        System.out.println("Moeda adicionada com sucesso!");
    }
    // Remove uma moeda específica da lista.
    public void remover(Moeda moeda) {
    	// Utiliza o método 'equals' da classe Moeda para encontrar e remover o objeto.
        if (this.listaMoedas.remove(moeda)) {
            System.out.println("Moeda removida com sucesso!");
        } else {
            System.out.println("Moeda não encontrada no cofrinho.");
        }
    }

    public void listagemMoedas() {
        if (listaMoedas.isEmpty()) {
            System.out.println("O cofrinho está vazio.");
            return;
        }
        System.out.println("--- Moedas no cofrinho ---");
        for (Moeda moeda : listaMoedas) {
            moeda.info();
        }
        System.out.println("--------------------------");
    }
 // Calcula o valor total do cofrinho convertido para Real.
    public double totalConvertido() {
        double total = 0;
     // Percorre a lista e soma o valor convertido de cada moeda.
        for (Moeda moeda : listaMoedas) {
            total += moeda.converter();
        }
        return total;
    }
}