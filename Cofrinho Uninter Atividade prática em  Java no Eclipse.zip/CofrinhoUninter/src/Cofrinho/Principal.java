package Cofrinho;

import java.util.Scanner;
//A classe Principal é o ponto de entrada do programa e contém o menu de interação com o usuário.
public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();

        int opcao;
     // Loop principal que exibe o menu e processa a escolha do usuário.
        do {
            System.out.println("\n--- MENU COFRINHO ---");
            System.out.println("1. Adicionar Moeda");
            System.out.println("2. Remover Moeda");
            System.out.println("3. Listar Moedas");
            System.out.println("4. Calcular Total Convertido para Real");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                	// Lógica para adicionar uma moeda.
                    System.out.println("--- ADICIONAR MOEDA ---");
                    System.out.println("1. Real");
                    System.out.println("2. Dólar");
                    System.out.println("3. Euro");
                    System.out.print("Escolha o tipo de moeda: ");
                    int tipoMoeda = scanner.nextInt();

                    System.out.print("Digite o valor: ");
                    double valor = scanner.nextDouble();

                    Moeda novaMoeda = null;
                    if (tipoMoeda == 1) {
                        novaMoeda = new Real(valor);
                    } else if (tipoMoeda == 2) {
                        novaMoeda = new Dolar(valor);
                    } else if (tipoMoeda == 3) {
                        novaMoeda = new Euro(valor);
                    }

                    if (novaMoeda != null) {
                        cofrinho.adicionar(novaMoeda);
                    } else {
                        System.out.println("Opção de moeda inválida.");
                    }
                    break;
                case 2:
                	// Lógica para remover uma moeda.
                    System.out.println("--- REMOVER MOEDA ---");
                    System.out.println("1. Real");
                    System.out.println("2. Dólar");
                    System.out.println("3. Euro");
                    System.out.print("Escolha o tipo de moeda a ser removida: ");
                    int tipoMoedaRemover = scanner.nextInt();
                    System.out.print("Digite o valor da moeda a ser removida: ");
                    double valorRemover = scanner.nextDouble();

                    Moeda moedaParaRemover = null;
                    if (tipoMoedaRemover == 1) {
                        moedaParaRemover = new Real(valorRemover);
                    } else if (tipoMoedaRemover == 2) {
                        moedaParaRemover = new Dolar(valorRemover);
                    } else if (tipoMoedaRemover == 3) {
                        moedaParaRemover = new Euro(valorRemover);
                    }

                    if (moedaParaRemover != null) {
                        cofrinho.remover(moedaParaRemover);
                    } else {
                        System.out.println("Opção de moeda inválida.");
                    }
                    break;
                case 3:
                    cofrinho.listagemMoedas();
                    break;
                case 4:
                    double total = cofrinho.totalConvertido();
                    System.out.printf("O valor total do cofrinho convertido para Real é: R$%.2f\n", total);
                    break;
                case 0:
                    System.out.println("Saindo do programa. Obrigado!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 0);// O loop continua enquanto o usuário não escolher 'Sair'.

        scanner.close();// Fecha o Scanner para liberar recursos.
    }
}