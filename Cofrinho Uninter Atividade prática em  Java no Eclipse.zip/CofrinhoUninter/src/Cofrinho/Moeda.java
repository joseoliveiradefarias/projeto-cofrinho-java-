public abstract class Moeda {
    protected double valor;
 // O atributo 'valor' armazena o valor da moeda.
    public Moeda(double valor) {
        this.valor = valor;
    }
    // Construtor para inicializar o valor da moeda.
    public double getValor() {
        return valor;
    }
 // Este método sobrescreve o padrão para permitir a comparação de moedas por valor e tipo.
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Moeda outraMoeda = (Moeda) obj;
        return Double.compare(outraMoeda.valor, this.valor) == 0;
    }
 // Método abstrato para exibir informações da moeda. Cada classe filha implementa de forma diferente.
    public abstract void info();
    // Método abstrato para converter a moeda para Real. Cada classe filha implementa a sua taxa.
    public abstract double converter();
}