package Cofrinho;

public class Dolar extends Moeda {
    private static final double TAXA_DOLAR = 5.25;

    public Dolar(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Moeda: Dólar - Valor: US$" + valor);
    }

    @Override
    public double converter() {
        return this.valor * TAXA_DOLAR;
    }
}